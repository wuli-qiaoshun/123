$(function(){
	

		$("#xiala1").mouseover(function(){
			$("#login1").show(500);
		}).click(function(){
			$("#login1").hide(500);
		});

			function user(){
			var name=$("#name").val();
			if(name==""){
				$("#dc1").addClass("cuo");
				$("#dc1").html("用户名不能为空！");
				return false;
			}
			else{
				$("#dc1").addClass("dui");
				$("#dc1").html("用户名格式正确！");
				return true;
			}
			
		};
		$("#name").blur(user);

		
		function pwd(){
			var pwd=$("#pwd").val();
			if(pwd.length<6){
				$("#dc2").addClass("cuo");
				$("#dc2").html("密码不能小于6位！");
				return false; 	
			}
			else{
				$("#dc2").addClass("dui");
				$("#dc2").html("密码格式正确！");
				return true;
			}
		};
		$("#pwd").blur(pwd);
		
		
	
		function shouji(){
			var shouji=$("#shouji").val();
			if(shouji.length<11){
				$("#dc3").addClass("cuo");
				$("#dc3").html("手机不能小于11位！");
				return false; 	
			}
			else{
				$("#dc3").addClass("dui");
				$("#dc3").html("手机号码正确！");
				return true;
			}
			};
			$("#shouji").blur(shouji);
		
		var num=Math.floor(Math.random()*1000000+6);
		$("#huoqu").click(function(){
			alert("您的验证码为："+num);
		})
	
		function yanz(){
			var yan=$("#yanzheng").val();
			if(yan==""){
				$("#dc4").addClass("cuo");
				$("#dc4").html("请输入验证码！");
				return false;
			}
			else if(yan!=num){
				$("#dc4").addClass("cuo");
				$("#dc4").html("验证码不正确!");
				return false;
			}
			else{
				$("#dc4").addClass("dui");
				$("#dc4").html("验证码正确！");
				return true;
			}
		};
		$("#yanzheng").blur(yanz);
		
		
		$(".tijiao").submit(function(){
			if(!user()||!pwd()||!shouji()||!yanz()){
				alert("注册失败！请填写正确的数据！");
				return false;
			}
			else{
				alert("注册成功！");
			}
		})

		$("#pwd").blur(function(){
			var pwd=$("#pwd").val();
			if(pwd.length>=6 && pwd.length<=9){
				$("#qiang_1").addClass("ruo");
				
			}
			else if(pwd.length>9 && pwd.length<=12){
				$("#qiang_1").removeClass("ruo");
				$("#qiang_2").addClass("ruo");
			}
			else if(pwd.length>12 && pwd.length<=16){
				$("#qiang_2").removeClass("ruo");
				$("#qiang_3").addClass("ruo");
			}
			else{
				$("#qiang_1").removeClass("ruo");
				$("#qiang_2").removeClass("ruo");
				$("#qiang_3").removeClass("ruo");
			}
		})	


})